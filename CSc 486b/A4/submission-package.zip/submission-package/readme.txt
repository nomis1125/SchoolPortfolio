NOTE:

This code does not compile or even run.

Since I was unabel to complete as well as fix parts of the code I just went along and made an attempt to complete some of the other parts of the assignment in hopes of getting some partial marks.

I apologize for the sloppyness and execution of this assignment.
