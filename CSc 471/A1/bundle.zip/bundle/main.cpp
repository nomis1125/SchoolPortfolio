#include "Paths.hpp"
#include "UniformLocations.glsl"
#include "assignment.hpp"

int main()
{
    // Your code goes here.
    return 0;
}
