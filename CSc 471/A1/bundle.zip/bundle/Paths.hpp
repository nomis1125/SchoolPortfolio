#pragma once

static constexpr char const* ShaderPath{"C:/Users/marov/Desktop/bundle/"};
static constexpr char const* DataPath{"C:/Users/marov/Desktop/bundle/"};
